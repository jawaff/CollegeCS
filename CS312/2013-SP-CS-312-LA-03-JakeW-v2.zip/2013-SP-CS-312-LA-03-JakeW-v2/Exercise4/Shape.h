
#ifndef _SHAPE
#define _SHAPE

class Shape
{
public:
	virtual float getPerimeter() = 0;
	virtual float getArea() = 0;
};

#endif
