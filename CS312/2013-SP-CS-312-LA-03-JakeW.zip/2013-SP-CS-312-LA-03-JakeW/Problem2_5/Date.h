
#ifndef _Date
#define _Date

#include <string>

using namespace std;

class Date
{
  private:
    int month;
    int day;
    int year;

  public:
    Date(int m, int d, int y);
    void progressOneDay();
    void progressOneMonth();
    void progressOneYear();
    void setDate(int m, int d, int y);
    int getDay();
    int getMonth();
    int getYear();
	string getNumDate();
	string getNamedDate();
};

#endif
