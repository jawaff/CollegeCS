///page 115 Exercise #4

///1. Year and Semester : 2013 SPRING
///2. Course Number : CS-312
///3. Course Title : OO Design/Implementation
///4. Work Number : LA-03
///5. Work Name : Exercises Ch 03
///6. Work Version : Version 1
///7. Long Date : Sunday, 11, February, 2013
///8. Author(s) Name(s) : Jake Waffle

#include <string>
#include <iostream>
#include <stdlib.h>
#include "Rectangle.h"

using namespace std;

int main()
{
	bool finished = false;
	string x, y, w, h;
	Rectangle rect;
	string exitCondition;

	cout << "\nYou're going to be adding in the dimensions for a Rectangle and this will print the results of some calculations\n\n";

	while(!finished)
	{
		cout << "Enter in an x-value: ";
		getline(cin,x);

		cout << "Enter in a y-value: ";
		getline(cin,y);

		cout << "Enter in a width: ";
		getline(cin,w);

		cout << "Enter in a height: ";
		getline(cin,h);

		rect.setDimensions(atoi(x.c_str()), atoi(y.c_str()), atoi(w.c_str()), atoi(h.c_str()));

		cout << "Your Rectangle's dimensions are:" << endl
			<< "x->" << rect.getX() << endl
			<< "y->" << rect.getY() << endl
			<< "width->" << rect.getWidth() << endl
			<< "height->" << rect.getHeight() << endl;

		cout << "The computed perimeter is: " << rect.getPerimeter() << endl
			<< "The computer area is: " << rect.getArea() << endl;

		cout << "Enter something if you'd like to quit: ";
		getline(cin, exitCondition);

		if(exitCondition != "")
		{
			finished = true;
		}
	}
	return 0;
}

