
#ifndef _RECTANGLE
#define _RECTANGLE

class Rectangle
{
private:
	int _x, _y, _width, _height;
public:
	void setDimensions(const int x,
                         const int y,
                         const int width,
                         const int height);
	int getX();
	int getY();
	int getWidth();
	int getHeight();
	int getPerimeter();
	int getArea();
};

#endif
